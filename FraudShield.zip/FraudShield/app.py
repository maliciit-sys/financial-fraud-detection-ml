"""
FraudShield Analytics Dashboard
Credit Card Fraud Detection System

Author: Muhammad Ali Tahir
MS Data Science Program, Superior University Lahore
"""

import streamlit as st
import pandas as pd
import numpy as np
import pickle
import json
import torch
import torch.nn as nn
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from sklearn.metrics import (
    confusion_matrix, classification_report, roc_curve, auc,
    precision_recall_curve, precision_score, recall_score, f1_score
)
import io

# ============================================================================
# PAGE CONFIGURATION
# ============================================================================
st.set_page_config(
    page_title="FraudShield Analytics",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ============================================================================
# CUSTOM CSS STYLING
# ============================================================================
st.markdown("""
<style>
    /* Main theme colors */
    :root {
        --primary-color: #1E3A5F;
        --secondary-color: #3498db;
        --success-color: #27ae60;
        --danger-color: #e74c3c;
        --warning-color: #f39c12;
    }
    
    /* Header styling */
    .main-header {
        background: linear-gradient(135deg, #1E3A5F 0%, #2C5282 100%);
        padding: 1.5rem;
        border-radius: 10px;
        margin-bottom: 1.5rem;
        color: white;
        text-align: center;
    }
    
    .main-header h1 {
        margin: 0;
        font-size: 2.2rem;
        font-weight: 700;
    }
    
    .main-header p {
        margin: 0.5rem 0 0 0;
        opacity: 0.9;
        font-size: 1rem;
    }
    
    /* Metric cards */
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.2rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    
    .metric-card-green {
        background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
    }
    
    .metric-card-blue {
        background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
    }
    
    .metric-card-orange {
        background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
    }
    
    .metric-card h3 {
        margin: 0;
        font-size: 1.8rem;
        font-weight: 700;
    }
    
    .metric-card p {
        margin: 0.3rem 0 0 0;
        font-size: 0.9rem;
        opacity: 0.9;
    }
    
    /* Risk gauge styling */
    .risk-low {
        color: #27ae60;
        font-weight: bold;
    }
    
    .risk-medium {
        color: #f39c12;
        font-weight: bold;
    }
    
    .risk-high {
        color: #e74c3c;
        font-weight: bold;
    }
    
    /* Tab styling */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        padding: 0 20px;
        background-color: #f0f2f6;
        border-radius: 5px;
        font-weight: 600;
    }
    
    .stTabs [aria-selected="true"] {
        background-color: #1E3A5F;
        color: white;
    }
    
    /* Footer */
    .footer {
        text-align: center;
        padding: 1rem;
        color: #666;
        font-size: 0.85rem;
        border-top: 1px solid #eee;
        margin-top: 2rem;
    }
    
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
</style>
""", unsafe_allow_html=True)

# ============================================================================
# MODEL DEFINITION
# ============================================================================
class FraudDetectionNN(nn.Module):
    """Neural Network for Fraud Detection"""
    def __init__(self, input_size, hidden_sizes=[256, 128, 64], dropout_rate=0.3):
        super(FraudDetectionNN, self).__init__()
        
        layers = []
        prev_size = input_size
        
        for hidden_size in hidden_sizes:
            layers.extend([
                nn.Linear(prev_size, hidden_size),
                nn.BatchNorm1d(hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout_rate)
            ])
            prev_size = hidden_size
        
        layers.append(nn.Linear(prev_size, 1))
        self.network = nn.Sequential(*layers)
    
    def forward(self, x):
        return self.network(x)

# ============================================================================
# LOAD MODEL AND ARTIFACTS
# ============================================================================
@st.cache_resource
def load_model_artifacts():
    """Load all model artifacts (cached for performance)"""
    
    # Load model config
    with open('model/model_config.json', 'r') as f:
        config = json.load(f)
    
    # Load encoders
    with open('model/encoders.pkl', 'rb') as f:
        encoders = pickle.load(f)
    
    # Load scaler
    with open('model/scaler.pkl', 'rb') as f:
        scaler = pickle.load(f)
    
    # Load training history
    with open('model/training_history.pkl', 'rb') as f:
        history = pickle.load(f)
    
    # Initialize model
    model = FraudDetectionNN(
        input_size=config['input_size'],
        hidden_sizes=config['hidden_sizes'],
        dropout_rate=config['dropout_rate']
    )
    
    # Load model weights
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.load_state_dict(torch.load('model/nn_model.pth', map_location=device))
    model.to(device)
    model.eval()
    
    return model, config, encoders, scaler, history, device

# ============================================================================
# PREPROCESSING FUNCTIONS
# ============================================================================
def preprocess_single_transaction(data, encoders, scaler):
    """Preprocess a single transaction for prediction"""
    
    # Create feature dictionary
    features = {}
    
    # Amount
    features['amt'] = float(data['amount'])
    
    # Gender encoding
    features['gender'] = encoders['gender'].get(data['gender'], 0)
    
    # City population
    features['city_pop'] = int(data['city_pop'])
    
    # Temporal features
    features['hour'] = int(data['hour'])
    features['day_of_week'] = int(data['day_of_week'])
    features['month'] = int(data['month'])
    
    # Age
    features['age'] = int(data['age'])
    
    # State encoding (target encoding based on fraud rate)
    features['state_encoded'] = encoders['state'].get(
        data['state'], 
        encoders['state_default']
    )
    
    # Category one-hot encoding
    categories = ['entertainment', 'food_dining', 'gas_transport', 'grocery_net',
                  'grocery_pos', 'health_fitness', 'home', 'kids_pets',
                  'misc_net', 'misc_pos', 'personal_care', 'shopping_net',
                  'shopping_pos', 'travel']
    
    for cat in categories:
        features[f'cat_{cat}'] = 1 if data['category'] == cat else 0
    
    # Create DataFrame for scaling
    df = pd.DataFrame([features])
    
    # Scale numeric features
    numeric_cols = ['amt', 'city_pop', 'age', 'hour', 'day_of_week', 'month', 'state_encoded']
    df[numeric_cols] = scaler.transform(df[numeric_cols])
    
    # Reorder columns to match training
    feature_cols = ['amt', 'gender', 'city_pop', 'hour', 'day_of_week', 'month', 'age', 
                    'state_encoded', 'cat_entertainment', 'cat_food_dining', 
                    'cat_gas_transport', 'cat_grocery_net', 'cat_grocery_pos',
                    'cat_health_fitness', 'cat_home', 'cat_kids_pets', 'cat_misc_net',
                    'cat_misc_pos', 'cat_personal_care', 'cat_shopping_net',
                    'cat_shopping_pos', 'cat_travel']
    
    return df[feature_cols].values.astype(np.float32)


def preprocess_batch(df, encoders, scaler):
    """Preprocess a batch of transactions"""
    
    processed_data = []
    
    # Expected columns mapping
    column_mapping = {
        'amt': ['amt', 'amount', 'transaction_amount'],
        'gender': ['gender', 'sex'],
        'city_pop': ['city_pop', 'city_population', 'population'],
        'category': ['category', 'merchant_category', 'merch_category'],
        'state': ['state', 'customer_state'],
        'hour': ['hour', 'transaction_hour'],
        'day_of_week': ['day_of_week', 'dayofweek', 'dow'],
        'month': ['month', 'transaction_month'],
        'age': ['age', 'customer_age']
    }
    
    # Normalize column names
    df_cols = df.columns.str.lower().str.strip()
    df.columns = df_cols
    
    # Find matching columns
    col_map = {}
    for target, options in column_mapping.items():
        for opt in options:
            if opt.lower() in df_cols.tolist():
                col_map[target] = opt.lower()
                break
    
    # Check for datetime column to extract temporal features
    datetime_cols = ['trans_date_trans_time', 'datetime', 'timestamp', 'trans_time']
    has_datetime = False
    datetime_col = None
    
    for col in datetime_cols:
        if col in df_cols.tolist():
            has_datetime = True
            datetime_col = col
            break
    
    # Check for DOB to calculate age
    dob_cols = ['dob', 'date_of_birth', 'birthdate']
    has_dob = False
    dob_col = None
    
    for col in dob_cols:
        if col in df_cols.tolist():
            has_dob = True
            dob_col = col
            break
    
    # Process each row
    results = []
    
    for idx, row in df.iterrows():
        features = {}
        
        # Amount
        amt_col = col_map.get('amt', 'amt')
        features['amt'] = float(row.get(amt_col, 0))
        
        # Gender
        gender_col = col_map.get('gender', 'gender')
        gender_val = str(row.get(gender_col, 'M')).upper()
        features['gender'] = encoders['gender'].get(gender_val, 0)
        
        # City population
        city_pop_col = col_map.get('city_pop', 'city_pop')
        features['city_pop'] = int(row.get(city_pop_col, 50000))
        
        # Temporal features
        if has_datetime:
            try:
                dt = pd.to_datetime(row[datetime_col])
                features['hour'] = dt.hour
                features['day_of_week'] = dt.dayofweek
                features['month'] = dt.month
            except:
                features['hour'] = int(row.get(col_map.get('hour', 'hour'), 12))
                features['day_of_week'] = int(row.get(col_map.get('day_of_week', 'day_of_week'), 3))
                features['month'] = int(row.get(col_map.get('month', 'month'), 6))
        else:
            features['hour'] = int(row.get(col_map.get('hour', 'hour'), 12))
            features['day_of_week'] = int(row.get(col_map.get('day_of_week', 'day_of_week'), 3))
            features['month'] = int(row.get(col_map.get('month', 'month'), 6))
        
        # Age
        if has_dob and has_datetime:
            try:
                dob = pd.to_datetime(row[dob_col])
                trans_dt = pd.to_datetime(row[datetime_col])
                features['age'] = (trans_dt - dob).days // 365
            except:
                features['age'] = int(row.get(col_map.get('age', 'age'), 45))
        else:
            features['age'] = int(row.get(col_map.get('age', 'age'), 45))
        
        # State encoding
        state_col = col_map.get('state', 'state')
        state_val = str(row.get(state_col, 'CA')).upper()
        features['state_encoded'] = encoders['state'].get(
            state_val, 
            encoders['state_default']
        )
        
        # Category one-hot encoding
        categories = ['entertainment', 'food_dining', 'gas_transport', 'grocery_net',
                      'grocery_pos', 'health_fitness', 'home', 'kids_pets',
                      'misc_net', 'misc_pos', 'personal_care', 'shopping_net',
                      'shopping_pos', 'travel']
        
        category_col = col_map.get('category', 'category')
        category_val = str(row.get(category_col, 'misc_pos')).lower().replace(' ', '_')
        
        for cat in categories:
            features[f'cat_{cat}'] = 1 if category_val == cat else 0
        
        results.append(features)
    
    # Create DataFrame
    result_df = pd.DataFrame(results)
    
    # Scale numeric features
    numeric_cols = ['amt', 'city_pop', 'age', 'hour', 'day_of_week', 'month', 'state_encoded']
    result_df[numeric_cols] = scaler.transform(result_df[numeric_cols])
    
    # Reorder columns
    feature_cols = ['amt', 'gender', 'city_pop', 'hour', 'day_of_week', 'month', 'age',
                    'state_encoded', 'cat_entertainment', 'cat_food_dining',
                    'cat_gas_transport', 'cat_grocery_net', 'cat_grocery_pos',
                    'cat_health_fitness', 'cat_home', 'cat_kids_pets', 'cat_misc_net',
                    'cat_misc_pos', 'cat_personal_care', 'cat_shopping_net',
                    'cat_shopping_pos', 'cat_travel']
    
    return result_df[feature_cols].values.astype(np.float32)


# ============================================================================
# PREDICTION FUNCTIONS
# ============================================================================
def predict_single(model, features, device):
    """Make prediction for a single transaction"""
    with torch.no_grad():
        X = torch.tensor(features, dtype=torch.float32).to(device)
        output = model(X)
        probability = torch.sigmoid(output).cpu().numpy()[0][0]
    return probability


def predict_batch(model, features, device, batch_size=1024):
    """Make predictions for a batch of transactions"""
    model.eval()
    all_probabilities = []
    
    with torch.no_grad():
        for i in range(0, len(features), batch_size):
            batch = features[i:i+batch_size]
            X = torch.tensor(batch, dtype=torch.float32).to(device)
            outputs = model(X).squeeze()
            probs = torch.sigmoid(outputs).cpu().numpy()
            
            if probs.ndim == 0:
                probs = np.array([probs.item()])
            
            all_probabilities.extend(probs)
    
    return np.array(all_probabilities)


# ============================================================================
# VISUALIZATION FUNCTIONS
# ============================================================================
def create_gauge_chart(probability, threshold=0.5):
    """Create a fraud probability gauge chart"""
    
    # Determine color based on probability
    if probability < 0.3:
        color = "#27ae60"  # Green
        risk_level = "Low Risk"
    elif probability < 0.7:
        color = "#f39c12"  # Orange
        risk_level = "Medium Risk"
    else:
        color = "#e74c3c"  # Red
        risk_level = "High Risk"
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=probability * 100,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': f"Fraud Probability<br><span style='font-size:0.8em;color:{color}'>{risk_level}</span>"},
        number={'suffix': "%", 'font': {'size': 40}},
        gauge={
            'axis': {'range': [0, 100], 'tickwidth': 1},
            'bar': {'color': color},
            'bgcolor': "white",
            'borderwidth': 2,
            'bordercolor': "gray",
            'steps': [
                {'range': [0, 30], 'color': '#d5f5e3'},
                {'range': [30, 70], 'color': '#fdebd0'},
                {'range': [70, 100], 'color': '#fadbd8'}
            ],
            'threshold': {
                'line': {'color': "black", 'width': 4},
                'thickness': 0.75,
                'value': threshold * 100
            }
        }
    ))
    
    fig.update_layout(
        height=300,
        margin=dict(l=20, r=20, t=50, b=20)
    )
    
    return fig


def create_roc_curve(y_true, y_probs):
    """Create ROC curve visualization"""
    fpr, tpr, _ = roc_curve(y_true, y_probs)
    roc_auc = auc(fpr, tpr)
    
    fig = go.Figure()
    
    # ROC curve
    fig.add_trace(go.Scatter(
        x=fpr, y=tpr,
        mode='lines',
        name=f'ROC Curve (AUC = {roc_auc:.4f})',
        line=dict(color='#3498db', width=3)
    ))
    
    # Diagonal line
    fig.add_trace(go.Scatter(
        x=[0, 1], y=[0, 1],
        mode='lines',
        name='Random Classifier',
        line=dict(color='gray', width=2, dash='dash')
    ))
    
    fig.update_layout(
        title='ROC Curve',
        xaxis_title='False Positive Rate',
        yaxis_title='True Positive Rate',
        height=400,
        showlegend=True,
        legend=dict(x=0.6, y=0.1)
    )
    
    return fig, roc_auc


def create_pr_curve(y_true, y_probs):
    """Create Precision-Recall curve visualization"""
    precision, recall, _ = precision_recall_curve(y_true, y_probs)
    pr_auc = auc(recall, precision)
    
    fig = go.Figure()
    
    # PR curve
    fig.add_trace(go.Scatter(
        x=recall, y=precision,
        mode='lines',
        name=f'PR Curve (AUC = {pr_auc:.4f})',
        line=dict(color='#e74c3c', width=3)
    ))
    
    # Baseline
    baseline = y_true.mean()
    fig.add_trace(go.Scatter(
        x=[0, 1], y=[baseline, baseline],
        mode='lines',
        name=f'Baseline ({baseline:.4f})',
        line=dict(color='gray', width=2, dash='dash')
    ))
    
    fig.update_layout(
        title='Precision-Recall Curve',
        xaxis_title='Recall',
        yaxis_title='Precision',
        height=400,
        showlegend=True,
        legend=dict(x=0.1, y=0.1)
    )
    
    return fig, pr_auc


def create_confusion_matrix_plot(y_true, y_pred):
    """Create confusion matrix visualization"""
    cm = confusion_matrix(y_true, y_pred)
    
    # Create labels
    labels = ['Non-Fraud', 'Fraud']
    
    # Create heatmap
    fig = go.Figure(data=go.Heatmap(
        z=cm,
        x=labels,
        y=labels,
        text=[[f'{val:,}' for val in row] for row in cm],
        texttemplate='%{text}',
        textfont={'size': 16},
        colorscale='Blues',
        showscale=True
    ))
    
    fig.update_layout(
        title='Confusion Matrix',
        xaxis_title='Predicted',
        yaxis_title='Actual',
        height=400
    )
    
    return fig, cm


def create_threshold_analysis_plot(y_true, y_probs):
    """Create threshold analysis visualization"""
    thresholds = np.arange(0.1, 1.0, 0.05)
    
    precisions = []
    recalls = []
    f1_scores = []
    
    for thresh in thresholds:
        y_pred = (y_probs >= thresh).astype(int)
        precisions.append(precision_score(y_true, y_pred, zero_division=0))
        recalls.append(recall_score(y_true, y_pred, zero_division=0))
        f1_scores.append(f1_score(y_true, y_pred, zero_division=0))
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=thresholds, y=precisions,
        mode='lines+markers',
        name='Precision',
        line=dict(color='#3498db', width=2)
    ))
    
    fig.add_trace(go.Scatter(
        x=thresholds, y=recalls,
        mode='lines+markers',
        name='Recall',
        line=dict(color='#27ae60', width=2)
    ))
    
    fig.add_trace(go.Scatter(
        x=thresholds, y=f1_scores,
        mode='lines+markers',
        name='F1 Score',
        line=dict(color='#e74c3c', width=2)
    ))
    
    # Find optimal threshold
    best_idx = np.argmax(f1_scores)
    best_thresh = thresholds[best_idx]
    
    fig.add_vline(
        x=best_thresh,
        line_dash="dash",
        line_color="purple",
        annotation_text=f"Optimal: {best_thresh:.2f}"
    )
    
    fig.update_layout(
        title='Metrics vs Threshold',
        xaxis_title='Threshold',
        yaxis_title='Score',
        height=400,
        showlegend=True,
        legend=dict(x=0.02, y=0.98)
    )
    
    return fig, best_thresh


def create_probability_distribution(y_probs, y_true=None):
    """Create probability distribution histogram"""
    fig = go.Figure()
    
    if y_true is not None:
        # Separate by class
        fig.add_trace(go.Histogram(
            x=y_probs[y_true == 0],
            name='Non-Fraud',
            opacity=0.7,
            marker_color='#27ae60',
            nbinsx=50
        ))
        
        fig.add_trace(go.Histogram(
            x=y_probs[y_true == 1],
            name='Fraud',
            opacity=0.7,
            marker_color='#e74c3c',
            nbinsx=50
        ))
    else:
        fig.add_trace(go.Histogram(
            x=y_probs,
            name='Predictions',
            opacity=0.7,
            marker_color='#3498db',
            nbinsx=50
        ))
    
    fig.update_layout(
        title='Prediction Probability Distribution',
        xaxis_title='Fraud Probability',
        yaxis_title='Count',
        barmode='overlay',
        height=400,
        showlegend=True
    )
    
    return fig


def create_training_curves(history):
    """Create training history visualization"""
    epochs = list(range(1, len(history['train_loss']) + 1))
    
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=('Loss', 'F1 Score', 'Precision & Recall', 'AUC Scores')
    )
    
    # Loss
    fig.add_trace(go.Scatter(x=epochs, y=history['train_loss'], name='Train Loss', 
                             line=dict(color='#3498db')), row=1, col=1)
    fig.add_trace(go.Scatter(x=epochs, y=history['val_loss'], name='Val Loss',
                             line=dict(color='#e74c3c')), row=1, col=1)
    
    # F1 Score
    fig.add_trace(go.Scatter(x=epochs, y=history['train_f1'], name='Train F1',
                             line=dict(color='#3498db')), row=1, col=2)
    fig.add_trace(go.Scatter(x=epochs, y=history['val_f1'], name='Val F1',
                             line=dict(color='#e74c3c')), row=1, col=2)
    
    # Precision & Recall
    fig.add_trace(go.Scatter(x=epochs, y=history['val_precision'], name='Val Precision',
                             line=dict(color='#27ae60')), row=2, col=1)
    fig.add_trace(go.Scatter(x=epochs, y=history['val_recall'], name='Val Recall',
                             line=dict(color='#f39c12')), row=2, col=1)
    
    # AUC
    fig.add_trace(go.Scatter(x=epochs, y=history['val_roc_auc'], name='ROC-AUC',
                             line=dict(color='#9b59b6')), row=2, col=2)
    fig.add_trace(go.Scatter(x=epochs, y=history['val_pr_auc'], name='PR-AUC',
                             line=dict(color='#1abc9c')), row=2, col=2)
    
    fig.update_layout(height=600, showlegend=True, title_text="Training History")
    
    return fig


# ============================================================================
# MAIN APPLICATION
# ============================================================================
def main():
    # Load model artifacts
    try:
        model, config, encoders, scaler, history, device = load_model_artifacts()
        model_loaded = True
    except Exception as e:
        st.error(f"Error loading model: {str(e)}")
        model_loaded = False
        return
    
    # Header
    st.markdown("""
    <div class="main-header">
        <h1>🛡️ FraudShield Analytics Dashboard</h1>
        <p>Advanced Credit Card Fraud Detection System | Neural Network Model</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.image("https://img.icons8.com/clouds/200/000000/security-checked.png", width=150)
        st.markdown("### 📊 Model Information")
        
        st.markdown(f"""
        **Architecture:**  
        `{config['input_size']} → {' → '.join(map(str, config['hidden_sizes']))} → 1`
        
        **Parameters:** 48,001  
        **Dropout:** {config['dropout_rate']}  
        **Epochs Trained:** {config['epochs_trained']}
        
        ---
        
        **Performance Metrics:**
        - ROC-AUC: **0.9969**
        - PR-AUC: **0.8712**
        - Best F1: **0.8196** (@ 0.90)
        
        ---
        
        **Developer:**  
        Muhammad Ali Tahir  
        MS Data Science  
        Superior University
        """)
    
    # Top metrics row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown("""
        <div class="metric-card">
            <h3>0.9969</h3>
            <p>ROC-AUC Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-card metric-card-green">
            <h3>0.8712</h3>
            <p>PR-AUC Score</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="metric-card metric-card-blue">
            <h3>87.76%</h3>
            <p>Precision @ 0.90</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        st.markdown("""
        <div class="metric-card metric-card-orange">
            <h3>76.88%</h3>
            <p>Recall @ 0.90</p>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Main tabs
    tab1, tab2, tab3, tab4 = st.tabs([
        "🔍 Single Transaction", 
        "📁 Batch Processing", 
        "📈 Model Performance",
        "💰 Business Impact"
    ])
    
    # =========================================================================
    # TAB 1: Single Transaction Prediction
    # =========================================================================
    with tab1:
        st.markdown("### Analyze Single Transaction")
        st.markdown("Enter transaction details below to get instant fraud probability assessment.")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("#### 💳 Transaction Details")
            amount = st.number_input("Transaction Amount ($)", min_value=0.01, max_value=50000.0, value=100.0, step=10.0)
            
            category = st.selectbox("Merchant Category", [
                'entertainment', 'food_dining', 'gas_transport', 'grocery_net',
                'grocery_pos', 'health_fitness', 'home', 'kids_pets',
                'misc_net', 'misc_pos', 'personal_care', 'shopping_net',
                'shopping_pos', 'travel'
            ])
        
        with col2:
            st.markdown("#### 👤 Customer Details")
            gender = st.selectbox("Gender", ['M', 'F'])
            age = st.slider("Age", min_value=18, max_value=100, value=35)
            
            state = st.selectbox("State", sorted(encoders['state'].keys()))
        
        with col3:
            st.markdown("#### 🕐 Temporal Details")
            hour = st.slider("Hour of Day", min_value=0, max_value=23, value=14)
            day_of_week = st.selectbox("Day of Week", 
                                       ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                                       index=2)
            month = st.slider("Month", min_value=1, max_value=12, value=6)
            city_pop = st.number_input("City Population", min_value=100, max_value=10000000, value=50000, step=1000)
        
        # Convert day of week to number
        day_map = {'Monday': 0, 'Tuesday': 1, 'Wednesday': 2, 'Thursday': 3, 
                   'Friday': 4, 'Saturday': 5, 'Sunday': 6}
        
        if st.button("🔍 Analyze Transaction", type="primary", use_container_width=True):
            # Prepare data
            transaction_data = {
                'amount': amount,
                'category': category,
                'gender': gender,
                'age': age,
                'state': state,
                'hour': hour,
                'day_of_week': day_map[day_of_week],
                'month': month,
                'city_pop': city_pop
            }
            
            # Preprocess and predict
            features = preprocess_single_transaction(transaction_data, encoders, scaler)
            probability = predict_single(model, features, device)
            
            st.markdown("---")
            
            # Results
            col1, col2 = st.columns([1, 1])
            
            with col1:
                st.plotly_chart(create_gauge_chart(probability, threshold=0.9), use_container_width=True)
            
            with col2:
                st.markdown("### 📊 Analysis Results")
                
                if probability >= 0.9:
                    st.error(f"⚠️ **HIGH RISK TRANSACTION**")
                    st.markdown(f"Fraud Probability: **{probability*100:.2f}%**")
                    st.markdown("**Recommendation:** Block transaction and verify with customer")
                elif probability >= 0.5:
                    st.warning(f"⚡ **MEDIUM RISK TRANSACTION**")
                    st.markdown(f"Fraud Probability: **{probability*100:.2f}%**")
                    st.markdown("**Recommendation:** Flag for manual review")
                else:
                    st.success(f"✅ **LOW RISK TRANSACTION**")
                    st.markdown(f"Fraud Probability: **{probability*100:.2f}%**")
                    st.markdown("**Recommendation:** Approve transaction")
                
                st.markdown("---")
                st.markdown("#### Risk Factors")
                
                # Highlight risk factors
                risk_factors = []
                if amount > 500:
                    risk_factors.append(f"• High amount: ${amount:.2f}")
                if hour >= 22 or hour <= 5:
                    risk_factors.append(f"• Late night transaction: {hour}:00")
                if category in ['shopping_net', 'misc_net', 'grocery_net']:
                    risk_factors.append(f"• Online category: {category}")
                if age > 65:
                    risk_factors.append(f"• Elderly customer: {age} years")
                
                if risk_factors:
                    for factor in risk_factors:
                        st.markdown(factor)
                else:
                    st.markdown("• No significant risk factors detected")
    
    # =========================================================================
    # TAB 2: Batch Processing
    # =========================================================================
    with tab2:
        st.markdown("### Batch Transaction Processing")
        st.markdown("Upload a CSV file containing multiple transactions for bulk fraud analysis.")
        
        # File format info
        with st.expander("📋 Expected CSV Format"):
            st.markdown("""
            Your CSV should contain the following columns:
            
            | Column | Description | Example |
            |--------|-------------|---------|
            | `amt` | Transaction amount | 125.50 |
            | `category` | Merchant category | shopping_net |
            | `gender` | Customer gender (M/F) | M |
            | `age` | Customer age | 35 |
            | `state` | US State code | CA |
            | `hour` | Hour of transaction (0-23) | 14 |
            | `day_of_week` | Day (0=Mon, 6=Sun) | 2 |
            | `month` | Month (1-12) | 6 |
            | `city_pop` | City population | 50000 |
            
            **Alternative:** If your CSV has `trans_date_trans_time` and `dob` columns, temporal features and age will be calculated automatically.
            """)
        
        uploaded_file = st.file_uploader("Upload CSV File", type=['csv'])
        
        if uploaded_file is not None:
            # Read CSV
            df = pd.read_csv(uploaded_file)
            
            st.markdown(f"**Loaded {len(df):,} transactions**")
            
            # Preview
            st.markdown("#### Data Preview")
            st.dataframe(df.head(10), use_container_width=True)
            
            # Threshold selection
            threshold = st.slider("Classification Threshold", min_value=0.1, max_value=0.95, value=0.9, step=0.05)
            
            if st.button("🚀 Process Transactions", type="primary", use_container_width=True):
                with st.spinner("Processing transactions..."):
                    # Preprocess
                    features = preprocess_batch(df, encoders, scaler)
                    
                    # Predict
                    probabilities = predict_batch(model, features, device)
                    
                    # Add results to dataframe
                    results_df = df.copy()
                    results_df['fraud_probability'] = probabilities
                    results_df['fraud_prediction'] = (probabilities >= threshold).astype(int)
                    results_df['risk_level'] = pd.cut(
                        probabilities,
                        bins=[0, 0.3, 0.7, 1.0],
                        labels=['Low', 'Medium', 'High']
                    )
                
                st.success("✅ Processing complete!")
                
                # Summary statistics
                st.markdown("---")
                st.markdown("### 📊 Results Summary")
                
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Total Transactions", f"{len(results_df):,}")
                
                with col2:
                    fraud_count = results_df['fraud_prediction'].sum()
                    st.metric("Flagged as Fraud", f"{fraud_count:,}", 
                              delta=f"{fraud_count/len(results_df)*100:.1f}%")
                
                with col3:
                    high_risk = (results_df['risk_level'] == 'High').sum()
                    st.metric("High Risk", f"{high_risk:,}")
                
                with col4:
                    avg_prob = results_df['fraud_probability'].mean()
                    st.metric("Avg Probability", f"{avg_prob*100:.2f}%")
                
                # Distribution plot
                st.markdown("### Probability Distribution")
                fig = create_probability_distribution(probabilities)
                st.plotly_chart(fig, use_container_width=True)
                
                # Results table
                st.markdown("### Detailed Results")
                
                # Color code the results
                st.dataframe(
                    results_df[['fraud_probability', 'fraud_prediction', 'risk_level']].head(100),
                    use_container_width=True
                )
                
                # Download button
                csv_buffer = io.StringIO()
                results_df.to_csv(csv_buffer, index=False)
                csv_data = csv_buffer.getvalue()
                
                st.download_button(
                    label="📥 Download Results (CSV)",
                    data=csv_data,
                    file_name=f"fraud_predictions_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv",
                    use_container_width=True
                )
    
    # =========================================================================
    # TAB 3: Model Performance
    # =========================================================================
    with tab3:
        st.markdown("### Model Performance Dashboard")
        
        # Check if we have test data for evaluation
        st.markdown("#### 📁 Upload Test Data for Evaluation")
        st.markdown("Upload a CSV with actual labels (`is_fraud` column) to see full model performance metrics.")
        
        test_file = st.file_uploader("Upload Test CSV (with `is_fraud` column)", type=['csv'], key='test_data')
        
        if test_file is not None:
            test_df = pd.read_csv(test_file)
            
            # Check for label column
            label_col = None
            for col in ['is_fraud', 'fraud', 'label', 'target']:
                if col in test_df.columns.str.lower().tolist():
                    label_col = col
                    break
            
            if label_col is None:
                st.error("Could not find label column. Please ensure your CSV has an `is_fraud` column.")
            else:
                # Process and evaluate
                with st.spinner("Evaluating model..."):
                    features = preprocess_batch(test_df, encoders, scaler)
                    probabilities = predict_batch(model, features, device)
                    y_true = test_df[label_col].values
                
                st.success(f"✅ Evaluated on {len(y_true):,} transactions")
                
                # Threshold slider
                st.markdown("---")
                st.markdown("### 🎚️ Threshold Adjustment")
                threshold = st.slider(
                    "Classification Threshold",
                    min_value=0.1, max_value=0.95, value=0.9, step=0.05,
                    key='perf_threshold'
                )
                
                y_pred = (probabilities >= threshold).astype(int)
                
                # Calculate metrics
                precision = precision_score(y_true, y_pred, zero_division=0)
                recall = recall_score(y_true, y_pred, zero_division=0)
                f1 = f1_score(y_true, y_pred, zero_division=0)
                
                # Metrics at current threshold
                col1, col2, col3, col4 = st.columns(4)
                
                with col1:
                    st.metric("Precision", f"{precision*100:.2f}%")
                with col2:
                    st.metric("Recall", f"{recall*100:.2f}%")
                with col3:
                    st.metric("F1 Score", f"{f1:.4f}")
                with col4:
                    st.metric("Predicted Frauds", f"{y_pred.sum():,}")
                
                st.markdown("---")
                
                # Visualizations
                col1, col2 = st.columns(2)
                
                with col1:
                    fig_roc, roc_auc = create_roc_curve(y_true, probabilities)
                    st.plotly_chart(fig_roc, use_container_width=True)
                
                with col2:
                    fig_pr, pr_auc = create_pr_curve(y_true, probabilities)
                    st.plotly_chart(fig_pr, use_container_width=True)
                
                col1, col2 = st.columns(2)
                
                with col1:
                    fig_cm, cm = create_confusion_matrix_plot(y_true, y_pred)
                    st.plotly_chart(fig_cm, use_container_width=True)
                    
                    # Confusion matrix breakdown
                    tn, fp, fn, tp = cm.ravel()
                    st.markdown(f"""
                    **Confusion Matrix Breakdown:**
                    - True Positives: {tp:,} (Frauds correctly caught)
                    - True Negatives: {tn:,} (Non-frauds correctly identified)
                    - False Positives: {fp:,} (False alarms)
                    - False Negatives: {fn:,} (Frauds missed)
                    """)
                
                with col2:
                    fig_thresh, best_thresh = create_threshold_analysis_plot(y_true, probabilities)
                    st.plotly_chart(fig_thresh, use_container_width=True)
                    st.markdown(f"**Optimal Threshold (max F1):** {best_thresh:.2f}")
                
                # Probability distribution
                st.markdown("### Probability Distribution by Class")
                fig_dist = create_probability_distribution(probabilities, y_true)
                st.plotly_chart(fig_dist, use_container_width=True)
        
        else:
            # Show training history instead
            st.markdown("---")
            st.markdown("### 📈 Training History")
            st.markdown("*Upload test data above to see full evaluation metrics, or view training history below.*")
            
            fig_history = create_training_curves(history)
            st.plotly_chart(fig_history, use_container_width=True)
            
            # Final training metrics
            st.markdown("### Final Training Metrics")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Final Train Loss", f"{history['train_loss'][-1]:.4f}")
            with col2:
                st.metric("Final Val Loss", f"{history['val_loss'][-1]:.4f}")
            with col3:
                st.metric("Final ROC-AUC", f"{history['val_roc_auc'][-1]:.4f}")
            with col4:
                st.metric("Final PR-AUC", f"{history['val_pr_auc'][-1]:.4f}")
    
    # =========================================================================
    # TAB 4: Business Impact
    # =========================================================================
    with tab4:
        st.markdown("### 💰 Business Impact Calculator")
        st.markdown("Estimate the financial impact of fraud detection at different thresholds.")
        
        st.markdown("---")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Configuration")
            
            avg_fraud_amount = st.number_input(
                "Average Fraud Amount ($)", 
                min_value=100.0, max_value=10000.0, value=531.32, step=50.0
            )
            
            investigation_cost = st.number_input(
                "Cost per Investigation ($)",
                min_value=1.0, max_value=100.0, value=5.0, step=1.0
            )
            
            total_transactions = st.number_input(
                "Monthly Transactions",
                min_value=1000, max_value=10000000, value=500000, step=10000
            )
            
            fraud_rate = st.slider(
                "Estimated Fraud Rate (%)",
                min_value=0.1, max_value=5.0, value=0.39, step=0.1
            )
        
        with col2:
            st.markdown("#### Threshold Selection")
            
            threshold = st.slider(
                "Classification Threshold",
                min_value=0.1, max_value=0.95, value=0.9, step=0.05,
                key='business_threshold'
            )
            
            # Estimated metrics at threshold (based on test results)
            threshold_metrics = {
                0.1: {'precision': 0.022, 'recall': 0.999},
                0.2: {'precision': 0.030, 'recall': 0.995},
                0.3: {'precision': 0.041, 'recall': 0.991},
                0.4: {'precision': 0.058, 'recall': 0.988},
                0.5: {'precision': 0.085, 'recall': 0.985},
                0.6: {'precision': 0.135, 'recall': 0.969},
                0.7: {'precision': 0.241, 'recall': 0.947},
                0.8: {'precision': 0.625, 'recall': 0.859},
                0.9: {'precision': 0.878, 'recall': 0.769},
                0.95: {'precision': 0.970, 'recall': 0.625}
            }
            
            # Find closest threshold
            closest_thresh = min(threshold_metrics.keys(), key=lambda x: abs(x - threshold))
            precision = threshold_metrics[closest_thresh]['precision']
            recall = threshold_metrics[closest_thresh]['recall']
            
            st.markdown(f"**Estimated Precision:** {precision*100:.1f}%")
            st.markdown(f"**Estimated Recall:** {recall*100:.1f}%")
        
        st.markdown("---")
        st.markdown("### 📊 Financial Impact Analysis")
        
        # Calculations
        total_frauds = int(total_transactions * fraud_rate / 100)
        total_non_frauds = total_transactions - total_frauds
        
        # At given threshold
        true_positives = int(total_frauds * recall)
        false_negatives = total_frauds - true_positives
        
        predicted_frauds = int(true_positives / precision) if precision > 0 else 0
        false_positives = predicted_frauds - true_positives
        
        # Financial calculations
        fraud_prevented = true_positives * avg_fraud_amount
        fraud_missed = false_negatives * avg_fraud_amount
        investigation_costs = predicted_frauds * investigation_cost
        net_benefit = fraud_prevented - fraud_missed - investigation_costs
        
        # Display results
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("#### Fraud Detection")
            st.metric("Frauds Caught", f"{true_positives:,}", delta=f"{recall*100:.1f}%")
            st.metric("Frauds Missed", f"{false_negatives:,}", delta=f"-{(1-recall)*100:.1f}%", delta_color="inverse")
        
        with col2:
            st.markdown("#### Operational Load")
            st.metric("Transactions Flagged", f"{predicted_frauds:,}")
            st.metric("False Alarms", f"{false_positives:,}")
        
        with col3:
            st.markdown("#### Financial Impact")
            st.metric("Fraud Prevented", f"${fraud_prevented:,.2f}")
            st.metric("Net Monthly Benefit", f"${net_benefit:,.2f}", 
                      delta=f"${net_benefit:,.0f}")
        
        # Detailed breakdown
        st.markdown("---")
        st.markdown("### 📋 Detailed Financial Breakdown")
        
        breakdown_data = {
            'Category': [
                'Fraud Losses Prevented (TP × Avg Amount)',
                'Fraud Losses Incurred (FN × Avg Amount)',
                'Investigation Costs (Flagged × Cost)',
                'NET BENEFIT'
            ],
            'Amount': [
                f'+${fraud_prevented:,.2f}',
                f'-${fraud_missed:,.2f}',
                f'-${investigation_costs:,.2f}',
                f'${net_benefit:,.2f}'
            ]
        }
        
        breakdown_df = pd.DataFrame(breakdown_data)
        st.table(breakdown_df)
        
        # Comparison chart
        st.markdown("### 📈 Threshold Comparison")
        
        comparison_data = []
        for thresh, metrics in threshold_metrics.items():
            tp = int(total_frauds * metrics['recall'])
            fn = total_frauds - tp
            pred_frauds = int(tp / metrics['precision']) if metrics['precision'] > 0 else 0
            fp = pred_frauds - tp
            
            prevented = tp * avg_fraud_amount
            missed = fn * avg_fraud_amount
            inv_cost = pred_frauds * investigation_cost
            net = prevented - missed - inv_cost
            
            comparison_data.append({
                'Threshold': thresh,
                'Net Benefit': net,
                'Fraud Prevented': prevented,
                'Flagged Transactions': pred_frauds
            })
        
        comparison_df = pd.DataFrame(comparison_data)
        
        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=comparison_df['Threshold'],
            y=comparison_df['Net Benefit'],
            marker_color=['#e74c3c' if x < 0 else '#27ae60' for x in comparison_df['Net Benefit']],
            text=[f'${x:,.0f}' for x in comparison_df['Net Benefit']],
            textposition='outside'
        ))
        
        fig.update_layout(
            title='Net Benefit by Threshold',
            xaxis_title='Threshold',
            yaxis_title='Net Monthly Benefit ($)',
            height=400
        )
        
        st.plotly_chart(fig, use_container_width=True)
    
    # Footer
    st.markdown("""
    <div class="footer">
        <p>🛡️ FraudShield Analytics Dashboard | Developed by Muhammad Ali Tahir | MS Data Science, Superior University Lahore</p>
        <p>Model: Neural Network (22 features → 256 → 128 → 64 → 1) | ROC-AUC: 0.9969</p>
    </div>
    """, unsafe_allow_html=True)


if __name__ == "__main__":
    main()
