# 🛡️ FraudShield Analytics Dashboard

**Advanced Credit Card Fraud Detection System**

A professional Streamlit-based web application for real-time fraud detection using a Neural Network model trained on the Sparkov Credit Card Transaction dataset.

---

## 📊 Features

### 1. Single Transaction Analysis
- Enter individual transaction details
- Get instant fraud probability assessment
- Visual risk gauge with color-coded risk levels
- Automatic risk factor identification

### 2. Batch Processing
- Upload CSV files with multiple transactions
- Bulk fraud scoring and risk classification
- Download results as CSV
- Probability distribution visualization

### 3. Model Performance Dashboard
- Upload test data with labels for full evaluation
- Interactive ROC and Precision-Recall curves
- Confusion matrix visualization
- **Real-time threshold adjustment** with live metric updates
- Training history visualization

### 4. Business Impact Calculator
- Financial impact estimation at different thresholds
- Configurable parameters (fraud amount, investigation cost, etc.)
- Net benefit comparison across thresholds
- Detailed financial breakdown

---

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- pip (Python package manager)

### Installation

1. **Clone or download this folder**

2. **Install dependencies:**
```bash
cd FraudShield
pip install -r requirements.txt
```

3. **Run the application:**
```bash
streamlit run app.py
```

4. **Open your browser:**
The app will automatically open at `http://localhost:8501`

---

## 📁 Project Structure

```
FraudShield/
├── app.py                    # Main Streamlit application
├── requirements.txt          # Python dependencies
├── README.md                 # This file
└── model/
    ├── nn_model.pth          # Trained PyTorch model weights
    ├── scaler.pkl            # StandardScaler for feature scaling
    ├── encoders.pkl          # Category and state encoders
    ├── model_config.json     # Model architecture configuration
    └── training_history.pkl  # Training metrics history
```

---

## 📋 Input Data Format

### For Batch Processing

Your CSV should contain these columns:

| Column | Description | Example |
|--------|-------------|---------|
| `amt` | Transaction amount in USD | 125.50 |
| `category` | Merchant category | shopping_net |
| `gender` | Customer gender (M/F) | M |
| `age` | Customer age in years | 35 |
| `state` | US State code | CA |
| `hour` | Hour of transaction (0-23) | 14 |
| `day_of_week` | Day of week (0=Mon, 6=Sun) | 2 |
| `month` | Month (1-12) | 6 |
| `city_pop` | City population | 50000 |

**Available Categories:**
- entertainment, food_dining, gas_transport, grocery_net
- grocery_pos, health_fitness, home, kids_pets
- misc_net, misc_pos, personal_care, shopping_net
- shopping_pos, travel

**Alternative Format:**
If your CSV contains `trans_date_trans_time` and `dob` columns, temporal features and age will be calculated automatically.

### For Model Evaluation

Include an additional `is_fraud` column (0 or 1) to evaluate model performance.

---

## 🧠 Model Information

**Architecture:** Fully-Connected Neural Network
```
Input (22 features)
    ↓
Linear(256) → BatchNorm → ReLU → Dropout(0.3)
    ↓
Linear(128) → BatchNorm → ReLU → Dropout(0.3)
    ↓
Linear(64) → BatchNorm → ReLU → Dropout(0.3)
    ↓
Linear(1) → Sigmoid
    ↓
Output (Fraud Probability)
```

**Performance Metrics:**
| Metric | Value |
|--------|-------|
| ROC-AUC | 0.9969 |
| PR-AUC | 0.8712 |
| Precision @ 0.90 | 87.76% |
| Recall @ 0.90 | 76.88% |
| F1 Score @ 0.90 | 0.8196 |

**Training Details:**
- Dataset: Sparkov Credit Card Transactions (1.3M training samples)
- Epochs: 11 (Early Stopping)
- Optimizer: Adam
- Loss Function: Focal Loss (α=0.75, γ=2.0)
- Class Imbalance Handling: Weighted Random Sampling

---

## 🎚️ Threshold Guidelines

| Threshold | Use Case | Precision | Recall |
|-----------|----------|-----------|--------|
| 0.30 | Maximum fraud detection (flag all suspicious) | Low | High |
| 0.70 | Balanced (manual review queue) | Medium | Medium |
| **0.90** | **Recommended (optimal F1)** | **High** | **Medium** |
| 0.95 | High precision (auto-block) | Very High | Low |

---

## 💡 Tips

1. **For thesis demos:** Use the Single Transaction tab to show real-time predictions
2. **For batch testing:** Prepare a CSV with known labels to show confusion matrix
3. **For business discussions:** Use the Business Impact tab to show financial value
4. **Threshold adjustment:** Use the slider in Model Performance to show precision/recall tradeoff

---

## 👨‍💻 Developer

**Muhammad Ali Tahir**  
MS Data Science Program  
Superior University, Lahore, Pakistan

**Supervisor:** Dr. Jawad Ahmad

---

## 📄 License

This project is developed for academic purposes as part of MS Data Science thesis research.

---

## 🐛 Troubleshooting

**Issue:** Model files not found
```
Solution: Ensure the 'model/' folder contains all .pth, .pkl, and .json files
```

**Issue:** CUDA out of memory
```
Solution: The app automatically falls back to CPU if CUDA is unavailable
```

**Issue:** CSV upload fails
```
Solution: Check that column names match the expected format (case-insensitive)
```

---

## 📧 Support

For questions or issues, please contact the developer.
